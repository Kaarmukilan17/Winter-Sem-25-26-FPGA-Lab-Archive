
module aes_core (
    input         clk,
    input  [127:0] plaintext,
    input  [127:0] key,
    input          start,
    output [127:0] ciphertext,
    output         done
);
    wire [3:0]    round_cnt;
    wire          sel_final, sel_load, en;
    wire [1407:0] rkey_flat;   // 11 x 128-bit keys flattened
    wire [127:0]  current_rkey;
    wire [127:0]  state_out;

    aes_keyschedule u_ks (
        .key      (key),
        .rkey_flat(rkey_flat)
    );

    // Select rkey[round_cnt] from flat bus
    assign current_rkey = rkey_flat[round_cnt*128 +: 128];

    aes_fsm u_fsm (
        .clk       (clk),
        .start     (start),
        .round_cnt (round_cnt),
        .sel_final (sel_final),
        .sel_load  (sel_load),
        .en        (en),
        .done      (done)
    );

    aes_datapath u_dp (
        .clk       (clk),
        .plaintext (plaintext),
        .round_key (current_rkey),
        .sel_final (sel_final),
        .sel_load  (sel_load),
        .en        (en),
        .state_out (state_out)
    );

    assign ciphertext = state_out;
endmodule


// =========================================================
// FSM
// =========================================================
module aes_fsm (
    input            clk,
    input            start,
    output reg [3:0] round_cnt,
    output reg       sel_final,
    output reg       sel_load,
    output reg       en,
    output reg       done
);
    localparam IDLE        = 3'd0,
               INIT        = 3'd1,
               ROUND       = 3'd2,
               FINAL_ROUND = 3'd3,
               DONE_ST     = 3'd4;

    reg [2:0] state, next_state;

    always @(posedge clk)
        state <= next_state;

    always @(posedge clk) begin
        case (state)
            INIT:        round_cnt <= 4'd1;
            ROUND:       round_cnt <= round_cnt + 4'd1;
            FINAL_ROUND: round_cnt <= 4'd0;
            default:     round_cnt <= 4'd0;
        endcase
    end

    always @(*) begin
        case (state)
            IDLE:        next_state = start             ? INIT        : IDLE;
            INIT:        next_state = ROUND;
            ROUND:       next_state = (round_cnt==4'd9) ? FINAL_ROUND : ROUND;
            FINAL_ROUND: next_state = DONE_ST;
            DONE_ST:     next_state = IDLE;
            default:     next_state = IDLE;
        endcase
    end

    always @(*) begin
        sel_final = 1'b0;
        sel_load  = 1'b0;
        en        = 1'b0;
        done      = 1'b0;
        case (state)
            IDLE:        en = 1'b0;
            INIT:      begin sel_load = 1'b1; en = 1'b1; end
            ROUND:     begin sel_final = 1'b0; en = 1'b1; end
            FINAL_ROUND:begin sel_final = 1'b1; en = 1'b1; end
            DONE_ST:   begin done = 1'b1; en = 1'b0; end
        endcase
    end
endmodule


// =========================================================
// Datapath
// =========================================================
module aes_datapath (
    input         clk,
    input  [127:0] plaintext,
    input  [127:0] round_key,
    input          sel_final,
    input          sel_load,
    input          en,
    output [127:0] state_out
);
    reg  [127:0] state_reg;
    wire [127:0] sub_out, shift_out, mix_out, mux_mix, addrk_out;

    aes_subbytes   u_sub  (.state_in(state_reg),  .state_out(sub_out));
    aes_shiftrows  u_shift(.state_in(sub_out),     .state_out(shift_out));
    aes_mixcolumns u_mix  (.state_in(shift_out),   .state_out(mix_out));

    assign mux_mix   = sel_final ? shift_out : mix_out;
    assign addrk_out = mux_mix ^ round_key;

    always @(posedge clk) begin
        if (en) begin
            if (sel_load)
                state_reg <= plaintext ^ round_key;
            else
                state_reg <= addrk_out;
        end
    end

    assign state_out = state_reg;
endmodule


// =========================================================
// Key Schedule  â  flat 1408-bit output (11 x 128 bits)
//   rkey_flat[127:0]    = rkey[0]
//   rkey_flat[255:128]  = rkey[1]
//   ...
//   rkey_flat[1407:1280]= rkey[10]
// =========================================================
module aes_keyschedule (
    input  [127:0]  key,
    output [1407:0] rkey_flat
);
    wire [7:0] rcon [1:10];
    assign rcon[1]=8'h01; assign rcon[2]=8'h02;
    assign rcon[3]=8'h04; assign rcon[4]=8'h08;
    assign rcon[5]=8'h10; assign rcon[6]=8'h20;
    assign rcon[7]=8'h40; assign rcon[8]=8'h80;
    assign rcon[9]=8'h1b; assign rcon[10]=8'h36;

    // 44 words w[0..43]
    wire [31:0] w [0:43];

    assign w[0] = key[127:96];
    assign w[1] = key[95:64];
    assign w[2] = key[63:32];
    assign w[3] = key[31:0];

    genvar i;
    generate
        for (i = 1; i <= 10; i = i + 1) begin : ks_round
            wire [7:0] rot0, rot1, rot2, rot3;
            wire [7:0] sub0, sub1, sub2, sub3;

            // RotWord
            assign rot0 = w[4*i-1][23:16];
            assign rot1 = w[4*i-1][15:8];
            assign rot2 = w[4*i-1][7:0];
            assign rot3 = w[4*i-1][31:24];

            // SubWord
            aes_sbox sb0(.in(rot0),.out(sub0));
            aes_sbox sb1(.in(rot1),.out(sub1));
            aes_sbox sb2(.in(rot2),.out(sub2));
            aes_sbox sb3(.in(rot3),.out(sub3));

            // Key expansion
            assign w[4*i+0] = w[4*i-4] ^ {sub0^rcon[i], sub1, sub2, sub3};
            assign w[4*i+1] = w[4*i-3] ^ w[4*i+0];
            assign w[4*i+2] = w[4*i-2] ^ w[4*i+1];
            assign w[4*i+3] = w[4*i-1] ^ w[4*i+2];
        end
    endgenerate

    // Pack 11 round keys into flat bus
    // rkey_flat[k*128 +: 128] = {w[4k], w[4k+1], w[4k+2], w[4k+3]}
    genvar r;
    generate
        for (r = 0; r <= 10; r = r + 1) begin : rk_pack
            assign rkey_flat[r*128 +: 128] = {w[4*r], w[4*r+1], w[4*r+2], w[4*r+3]};
        end
    endgenerate
endmodule


// =========================================================
// MixColumns
// =========================================================
module aes_mixcolumns (
    input  [127:0] state_in,
    output [127:0] state_out
);
    function [7:0] xtime;
        input [7:0] b;
        begin
            xtime = b[7] ? ({b[6:0],1'b0} ^ 8'h1b) : {b[6:0],1'b0};
        end
    endfunction

    function [31:0] mix_col;
        input [31:0] col;
        reg [7:0] s0,s1,s2,s3,t0,t1,t2,t3;
        begin
            s0=col[31:24]; s1=col[23:16]; s2=col[15:8]; s3=col[7:0];
            t0=xtime(s0);  t1=xtime(s1);  t2=xtime(s2); t3=xtime(s3);
            mix_col[31:24] = t0^(t1^s1)^s2^s3;
            mix_col[23:16] = s0^t1^(t2^s2)^s3;
            mix_col[15:8]  = s0^s1^t2^(t3^s3);
            mix_col[7:0]   = (t0^s0)^s1^s2^t3;
        end
    endfunction

    assign state_out[127:96] = mix_col(state_in[127:96]);
    assign state_out[95:64]  = mix_col(state_in[95:64]);
    assign state_out[63:32]  = mix_col(state_in[63:32]);
    assign state_out[31:0]   = mix_col(state_in[31:0]);
endmodule


// =========================================================
// ShiftRows
// =========================================================
module aes_shiftrows (
    input  [127:0] state_in,
    output [127:0] state_out
);
    wire [7:0] s [0:3][0:3];
    genvar r, c;
    generate
        for (c = 0; c < 4; c = c + 1) begin : col_in
            for (r = 0; r < 4; r = r + 1) begin : row_in
                assign s[r][c] = state_in[127-(c*32)-(r*8) -: 8];
            end
        end
    endgenerate

    wire [7:0] sr [0:3][0:3];
    generate
        for (r = 0; r < 4; r = r + 1) begin : sr_row
            for (c = 0; c < 4; c = c + 1) begin : sr_col
                assign sr[r][c] = s[r][(c+r) % 4];
            end
        end
    endgenerate

    generate
        for (c = 0; c < 4; c = c + 1) begin : pack_col
            for (r = 0; r < 4; r = r + 1) begin : pack_row
                assign state_out[127-(c*32)-(r*8) -: 8] = sr[r][c];
            end
        end
    endgenerate
endmodule


// =========================================================
// SubBytes
// =========================================================
module aes_subbytes (
    input  [127:0] state_in,
    output [127:0] state_out
);
    genvar i;
    generate
        for (i = 0; i < 16; i = i + 1) begin : sb
            aes_sbox u_sbox (
                .in (state_in [8*i+7 : 8*i]),
                .out(state_out[8*i+7 : 8*i])
            );
        end
    endgenerate
endmodule


// =========================================================
// S-Box (ROM)
// =========================================================
module aes_sbox (
    input  [7:0] in,
    output [7:0] out
);
    reg [7:0] sbox [0:255];
    initial begin
        sbox[8'h00]=8'h63; sbox[8'h01]=8'h7c; sbox[8'h02]=8'h77; sbox[8'h03]=8'h7b;
        sbox[8'h04]=8'hf2; sbox[8'h05]=8'h6b; sbox[8'h06]=8'h6f; sbox[8'h07]=8'hc5;
        sbox[8'h08]=8'h30; sbox[8'h09]=8'h01; sbox[8'h0a]=8'h67; sbox[8'h0b]=8'h2b;
        sbox[8'h0c]=8'hfe; sbox[8'h0d]=8'hd7; sbox[8'h0e]=8'hab; sbox[8'h0f]=8'h76;
        sbox[8'h10]=8'hca; sbox[8'h11]=8'h82; sbox[8'h12]=8'hc9; sbox[8'h13]=8'h7d;
        sbox[8'h14]=8'hfa; sbox[8'h15]=8'h59; sbox[8'h16]=8'h47; sbox[8'h17]=8'hf0;
        sbox[8'h18]=8'had; sbox[8'h19]=8'hd4; sbox[8'h1a]=8'ha2; sbox[8'h1b]=8'haf;
        sbox[8'h1c]=8'h9c; sbox[8'h1d]=8'ha4; sbox[8'h1e]=8'h72; sbox[8'h1f]=8'hc0;
        sbox[8'h20]=8'hb7; sbox[8'h21]=8'hfd; sbox[8'h22]=8'h93; sbox[8'h23]=8'h26;
        sbox[8'h24]=8'h36; sbox[8'h25]=8'h3f; sbox[8'h26]=8'hf7; sbox[8'h27]=8'hcc;
        sbox[8'h28]=8'h34; sbox[8'h29]=8'ha5; sbox[8'h2a]=8'he5; sbox[8'h2b]=8'hf1;
        sbox[8'h2c]=8'h71; sbox[8'h2d]=8'hd8; sbox[8'h2e]=8'h31; sbox[8'h2f]=8'h15;
        sbox[8'h30]=8'h04; sbox[8'h31]=8'hc7; sbox[8'h32]=8'h23; sbox[8'h33]=8'hc3;
        sbox[8'h34]=8'h18; sbox[8'h35]=8'h96; sbox[8'h36]=8'h05; sbox[8'h37]=8'h9a;
        sbox[8'h38]=8'h07; sbox[8'h39]=8'h12; sbox[8'h3a]=8'h80; sbox[8'h3b]=8'he2;
        sbox[8'h3c]=8'heb; sbox[8'h3d]=8'h27; sbox[8'h3e]=8'hb2; sbox[8'h3f]=8'h75;
        sbox[8'h40]=8'h09; sbox[8'h41]=8'h83; sbox[8'h42]=8'h2c; sbox[8'h43]=8'h1a;
        sbox[8'h44]=8'h1b; sbox[8'h45]=8'h6e; sbox[8'h46]=8'h5a; sbox[8'h47]=8'ha0;
        sbox[8'h48]=8'h52; sbox[8'h49]=8'h3b; sbox[8'h4a]=8'hd6; sbox[8'h4b]=8'hb3;
        sbox[8'h4c]=8'h29; sbox[8'h4d]=8'he3; sbox[8'h4e]=8'h2f; sbox[8'h4f]=8'h84;
        sbox[8'h50]=8'h53; sbox[8'h51]=8'hd1; sbox[8'h52]=8'h00; sbox[8'h53]=8'hed;
        sbox[8'h54]=8'h20; sbox[8'h55]=8'hfc; sbox[8'h56]=8'hb1; sbox[8'h57]=8'h5b;
        sbox[8'h58]=8'h6a; sbox[8'h59]=8'hcb; sbox[8'h5a]=8'hbe; sbox[8'h5b]=8'h39;
        sbox[8'h5c]=8'h4a; sbox[8'h5d]=8'h4c; sbox[8'h5e]=8'h58; sbox[8'h5f]=8'hcf;
        sbox[8'h60]=8'hd0; sbox[8'h61]=8'hef; sbox[8'h62]=8'haa; sbox[8'h63]=8'hfb;
        sbox[8'h64]=8'h43; sbox[8'h65]=8'h4d; sbox[8'h66]=8'h33; sbox[8'h67]=8'h85;
        sbox[8'h68]=8'h45; sbox[8'h69]=8'hf9; sbox[8'h6a]=8'h02; sbox[8'h6b]=8'h7f;
        sbox[8'h6c]=8'h50; sbox[8'h6d]=8'h3c; sbox[8'h6e]=8'h9f; sbox[8'h6f]=8'ha8;
        sbox[8'h70]=8'h51; sbox[8'h71]=8'ha3; sbox[8'h72]=8'h40; sbox[8'h73]=8'h8f;
        sbox[8'h74]=8'h92; sbox[8'h75]=8'h9d; sbox[8'h76]=8'h38; sbox[8'h77]=8'hf5;
        sbox[8'h78]=8'hbc; sbox[8'h79]=8'hb6; sbox[8'h7a]=8'hda; sbox[8'h7b]=8'h21;
        sbox[8'h7c]=8'h10; sbox[8'h7d]=8'hff; sbox[8'h7e]=8'hf3; sbox[8'h7f]=8'hd2;
        sbox[8'h80]=8'hcd; sbox[8'h81]=8'h0c; sbox[8'h82]=8'h13; sbox[8'h83]=8'hec;
        sbox[8'h84]=8'h5f; sbox[8'h85]=8'h97; sbox[8'h86]=8'h44; sbox[8'h87]=8'h17;
        sbox[8'h88]=8'hc4; sbox[8'h89]=8'ha7; sbox[8'h8a]=8'h7e; sbox[8'h8b]=8'h3d;
        sbox[8'h8c]=8'h64; sbox[8'h8d]=8'h5d; sbox[8'h8e]=8'h19; sbox[8'h8f]=8'h73;
        sbox[8'h90]=8'h60; sbox[8'h91]=8'h81; sbox[8'h92]=8'h4f; sbox[8'h93]=8'hdc;
        sbox[8'h94]=8'h22; sbox[8'h95]=8'h2a; sbox[8'h96]=8'h90; sbox[8'h97]=8'h88;
        sbox[8'h98]=8'h46; sbox[8'h99]=8'hee; sbox[8'h9a]=8'hb8; sbox[8'h9b]=8'h14;
        sbox[8'h9c]=8'hde; sbox[8'h9d]=8'h5e; sbox[8'h9e]=8'h0b; sbox[8'h9f]=8'hdb;
        sbox[8'ha0]=8'he0; sbox[8'ha1]=8'h32; sbox[8'ha2]=8'h3a; sbox[8'ha3]=8'h0a;
        sbox[8'ha4]=8'h49; sbox[8'ha5]=8'h06; sbox[8'ha6]=8'h24; sbox[8'ha7]=8'h5c;
        sbox[8'ha8]=8'hc2; sbox[8'ha9]=8'hd3; sbox[8'haa]=8'hac; sbox[8'hab]=8'h62;
        sbox[8'hac]=8'h91; sbox[8'had]=8'h95; sbox[8'hae]=8'he4; sbox[8'haf]=8'h79;
        sbox[8'hb0]=8'he7; sbox[8'hb1]=8'hc8; sbox[8'hb2]=8'h37; sbox[8'hb3]=8'h6d;
        sbox[8'hb4]=8'h8d; sbox[8'hb5]=8'hd5; sbox[8'hb6]=8'h4e; sbox[8'hb7]=8'ha9;
        sbox[8'hb8]=8'h6c; sbox[8'hb9]=8'h56; sbox[8'hba]=8'hf4; sbox[8'hbb]=8'hea;
        sbox[8'hbc]=8'h65; sbox[8'hbd]=8'h7a; sbox[8'hbe]=8'hae; sbox[8'hbf]=8'h08;
        sbox[8'hc0]=8'hba; sbox[8'hc1]=8'h78; sbox[8'hc2]=8'h25; sbox[8'hc3]=8'h2e;
        sbox[8'hc4]=8'h1c; sbox[8'hc5]=8'ha6; sbox[8'hc6]=8'hb4; sbox[8'hc7]=8'hc6;
        sbox[8'hc8]=8'he8; sbox[8'hc9]=8'hdd; sbox[8'hca]=8'h74; sbox[8'hcb]=8'h1f;
        sbox[8'hcc]=8'h4b; sbox[8'hcd]=8'hbd; sbox[8'hce]=8'h8b; sbox[8'hcf]=8'h8a;
        sbox[8'hd0]=8'h70; sbox[8'hd1]=8'h3e; sbox[8'hd2]=8'hb5; sbox[8'hd3]=8'h66;
        sbox[8'hd4]=8'h48; sbox[8'hd5]=8'h03; sbox[8'hd6]=8'hf6; sbox[8'hd7]=8'h0e;
        sbox[8'hd8]=8'h61; sbox[8'hd9]=8'h35; sbox[8'hda]=8'h57; sbox[8'hdb]=8'hb9;
        sbox[8'hdc]=8'h86; sbox[8'hdd]=8'hc1; sbox[8'hde]=8'h1d; sbox[8'hdf]=8'h9e;
        sbox[8'he0]=8'he1; sbox[8'he1]=8'hf8; sbox[8'he2]=8'h98; sbox[8'he3]=8'h11;
        sbox[8'he4]=8'h69; sbox[8'he5]=8'hd9; sbox[8'he6]=8'h8e; sbox[8'he7]=8'h94;
        sbox[8'he8]=8'h9b; sbox[8'he9]=8'h1e; sbox[8'hea]=8'h87; sbox[8'heb]=8'he9;
        sbox[8'hec]=8'hce; sbox[8'hed]=8'h55; sbox[8'hee]=8'h28; sbox[8'hef]=8'hdf;
        sbox[8'hf0]=8'h8c; sbox[8'hf1]=8'ha1; sbox[8'hf2]=8'h89; sbox[8'hf3]=8'h0d;
        sbox[8'hf4]=8'hbf; sbox[8'hf5]=8'he6; sbox[8'hf6]=8'h42; sbox[8'hf7]=8'h68;
        sbox[8'hf8]=8'h41; sbox[8'hf9]=8'h99; sbox[8'hfa]=8'h2d; sbox[8'hfb]=8'h0f;
        sbox[8'hfc]=8'hb0; sbox[8'hfd]=8'h54; sbox[8'hfe]=8'hbb; sbox[8'hff]=8'h16;
    end
    assign out = sbox[in];
endmodule