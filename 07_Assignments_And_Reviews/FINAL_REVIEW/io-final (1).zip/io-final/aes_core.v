module aes_core (
    input           clk,
    input           reset,
    input   [127:0] plaintext,
    input   [127:0] key,
	 input start,
	 
    output  [127:0] ciphertext,
    output          done
);

endmodule