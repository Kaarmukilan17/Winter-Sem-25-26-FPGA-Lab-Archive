/* Quartus Prime Version 25.1std.0 Build 1129 10/21/2025 SC Standard Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EP4CE115F29) Path("D:/23bec0137/REVIEW1/top_128bit_display_ADDROUNDDKEY/output_files/") File("top_module.sof") MfrSpec(OpMask(1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
